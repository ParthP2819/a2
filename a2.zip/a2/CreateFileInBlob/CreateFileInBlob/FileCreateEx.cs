using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure.Storage.Blobs;
using System.Text;

namespace CreateFileInBlob
{
    public static class FileCreateEx
    {
        [FunctionName("FileCreateEx")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=parthstorageaccounts;AccountKey=3GVQtyD1UaOA2Kjz6XuEw0yu/ku93bJ8tj5aFfJoKV1zfbv9Fl7zzzhvG88sk/xbSSVyZmWL41gT+ASt4W8XRA==;EndpointSuffix=core.windows.net";
            BlobServiceClient client = new BlobServiceClient(connectionString);
            string containerName = "blob-data";
            BlobContainerClient containerClient = client.GetBlobContainerClient(containerName);
            await containerClient.CreateIfNotExistsAsync();
            string name = req.Query["name"];

            BlobClient blob = containerClient.GetBlobClient(name+".txt");
            byte[] byteArray = Encoding.ASCII.GetBytes("Hello Dear" + " " + name);
            MemoryStream stream= new MemoryStream(byteArray);
            await blob.UploadAsync(stream);
            return new OkObjectResult($"File {name}.txt uploaded successfully.");
        }
    }
}
