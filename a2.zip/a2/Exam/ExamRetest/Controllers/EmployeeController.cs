﻿using ExamRetest.Data;
using ExamRetest.Models;
using ExamRetest.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamRetest.Controllers
{
    public class EmployeeController : Controller
    {
        public readonly ApplicationDbContext _db;
        public EmployeeController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
			IEnumerable<EmployeeDetails> empList = _db.Employees.ToList();
			return View(empList);
			//return View();
        }

		//GET
		public IActionResult getAll(int id)
		{
			EmployeeVM employeeVM = new()
			{
				employee = new(),
				roleList = _db.Roles.Select(i => new SelectListItem
				{
					Text = i.RoleName,
					Value = i.RoleId.ToString(),
				}).ToList()
			};

			if (id == null || id == 0)
			{
				return View(employeeVM);
			}
			return View(employeeVM);
		}

		[HttpPost, ActionName("UpaertM")]
		[ValidateAntiForgeryToken]
		public IActionResult getAll(EmployeeVM employeeVM)
		{

			_db.Employees.Add(employeeVM.employee);
			_db.SaveChanges();
			return RedirectToAction("Index");
		}
		
	}
}
