﻿using ExamRetest.Models;
using Microsoft.EntityFrameworkCore;

namespace ExamRetest.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<EmployeeDetails> Employees { get; set; }
        public DbSet<RoleType> Roles { get; set; }
    }
}
