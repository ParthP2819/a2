﻿using ExamRetest.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamRetest.Models.ViewModel
{
    public class EmployeeVM
    {
        public EmployeeDetails employee { get; set; }
        [ValidateNever]
        public IEnumerable<SelectListItem> roleList { get; set; }
    }
}
